SELECT Branch, 
       MONTH(STR_TO_DATE(Date, '%d-%m-%Y')) AS Month, 
       SUM(Total) AS Monthly_Sales,
       (SUM(Total) - LAG(SUM(Total)) OVER (PARTITION BY Branch ORDER BY MONTH(STR_TO_DATE(Date, '%d-%m-%Y')))) / LAG(SUM(Total))
       OVER (PARTITION BY Branch ORDER BY MONTH(STR_TO_DATE(Date, '%d-%m-%Y'))) AS Growth_Rate
FROM walmartsales.`walmartsales dataset - walmartsales`
GROUP BY Branch, Month
ORDER BY Growth_Rate DESC
LIMIT 1;