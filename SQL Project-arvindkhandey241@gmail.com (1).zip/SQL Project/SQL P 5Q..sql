SELECT City,
       Payment,
       COUNT(*) AS TransactionCount
FROM walmartsales.`walmartsales dataset - walmartsales`
GROUP BY City, Payment
ORDER BY City, TransactionCount DESC;