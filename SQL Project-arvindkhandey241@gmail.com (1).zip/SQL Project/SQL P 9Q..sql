SELECT
    `Customer ID`,
    SUM(Total) AS TotalSales
FROM
    walmartsales.`walmartsales dataset - walmartsales`
GROUP BY
    `Customer ID`
ORDER BY
    TotalSales DESC
LIMIT 5;
