WITH CustomerSpending AS (
    SELECT
        `Customer ID`,
        SUM(Total) AS TotalSpending
    FROM
       walmartsales.`walmartsales dataset - walmartsales`
    GROUP BY
        `Customer ID`
),
SpendingStats AS (
    SELECT
        AVG(TotalSpending) AS AverageSpending,
        STDDEV(TotalSpending) AS SpendingStdDev
    FROM
        CustomerSpending
)
SELECT
    cs.`Customer ID`,
    cs.TotalSpending,
    CASE
        WHEN cs.TotalSpending > (ss.AverageSpending + ss.SpendingStdDev) THEN 'High Spender'
        WHEN cs.TotalSpending < (ss.AverageSpending - ss.SpendingStdDev) THEN 'Low Spender'
        ELSE 'Medium Spender'
    END AS SpendingTier
FROM
    CustomerSpending cs,
    SpendingStats ss;
