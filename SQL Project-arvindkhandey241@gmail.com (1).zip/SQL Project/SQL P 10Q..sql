SELECT DAYNAME(Date) AS DayOfWeek,
       SUM(Total) AS TotalSales
FROM walmartsales.`walmartsales dataset - walmartsales`
GROUP BY DAYNAME(Date)
ORDER BY DayOfWeek;